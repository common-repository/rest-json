=== WP-Restify ===

Contributors: www.mastersoftwaresolutions.com
Tested up to: 1.0.1
Stable tag: 1.0.1
Author: Mastersoftwaresolutions

=== Description ===

This plugin extends the [WordPress JSON REST API] with new routes for WordPress registered menus.

=== Installation ===

This plugin requires having [WP API] installed and activated or it won't be of any use.

Install the plugin as you would with any WordPress plugin in your 'wp-content/plugins/' directory or equivalent.

Once installed, activate wp-restify from WordPress plugins dashboard page and you're ready to go.

=== Changelog ===

== 1.0.0 ==
First public release.
== 1.0.1 ==
second public release.

